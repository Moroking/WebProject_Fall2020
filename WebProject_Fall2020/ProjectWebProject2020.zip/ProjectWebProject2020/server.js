
//#region  node_modules
let express= require('express');
let app = express();
let bodyParser = require('body-parser');
let fs = require("fs");
let formidable = require('formidable');
let archiver = require('archiver');
let webSocket = require("ws");
const { v4: uuidv4 } = require('uuid');
const ejs = require("ejs");
const cors = require('cors');
const passport = require('passport');
const cookieSession = require('cookie-session')
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const path = require('path');
let mysql = require('mysql');
var passwordHash = require('password-hash');

//#endregion

let con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: null,
    database: "aboutme_maker"

  });

//#region Variables

let face_photo = "";
let gallery = [];
var dict = {};
let jsonDict = "";
let googleLogin = false;
let googleData = "";
let savedData = false;
let logout = false;
let googleAcc = false;
let passInc = false;
let passEmp = false;
let passCorr = false;
let Email_Cor = "";
let downloadable = false;
let cantDownload = false;

//#endregion

app.use(cors());

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*"); 
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.use(bodyParser.json()); 
app.use(bodyParser.urlencoded({extended : true}));

app.use(cookieSession({
    name: 'aboutMe_Maker',
    keys: ['key1', 'key2']
}))

const isLoggedIn = (req, res, next) => {
    if (req.user) {
        googleData = req.user;
    
        con.query(`SELECT email FROM users WHERE email = ?`, [googleData.emails[0]["value"]], function (err, result, fields) {
            if (err) throw err;
            if(result[0] == undefined )
            {
                var sql = `INSERT INTO users (name, email, isgoogle) VALUES (?,?,?)`;
                var que = [googleData.displayName, googleData.emails[0]["value"], '1'];
                con.query(sql, que, function (err, result) {
                  if (err) throw err;
                  console.log("Google User Added");
                });
            }
        });

        con.query(`SELECT email FROM userdata WHERE email = ?`, [googleData.emails[0]["value"]], function (err, result, fields) {
            if (err) throw err;
            if(result[0] == undefined)
            {
                savedData = false;
            }
            else{
                savedData = true;
            }
            console.log(savedData);
          });
          googleAcc = true;
          logout = false;

        next();
    } else {
        res.sendStatus(401);
    }
}
app.use('/', express.static(path.join(__dirname, '/')))
app.use(express.static('public'));

app.get('/', function (req, res){
    res.sendFile(__dirname + '/index.html');
});

app.use(passport.initialize());
app.use(passport.session());

app.get('/failed', (req, res) => res.send('You Failed to log in!'))

app.get('/good', isLoggedIn, function (req, res) {
    res.sendFile(path.join(__dirname+'/index.html'));
    googleLogin = true;

   
});

app.get('/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

app.get('/google/callback', passport.authenticate('google', { failureRedirect: '/failed' }),
  function(req, res) {
    res.redirect('/good');
  }
);

app.post('/login', function(req, res) {
    var email = req.body.email;
    var password = req.body.password;
    if (email && password) {
        con.query('SELECT password FROM users WHERE email = ?', [email], function(error, results, fields) {
            if (results.length > 0 && passwordHash.verify(password, results[0].password))  {
                googleAcc = false;
                passCorr = true;
                savedData = true;
                logout = false;
                Email_Cor = email;
                res.redirect('/');
            } else {
                passInc = true;
                res.redirect('/');
			}			
			res.end();
		});
    } 
    else {
        passInc = true;
        res.redirect('/');
    }
    
});

app.post('/register', function(req, res) {
    var email = req.body.email;
    var patt = /[a-zA-Z0-9]{3,64}@[a-zA-Z0-9]+.[a-zA-Z0-9.]+/i;
    var result = email.match(patt);
    var password = req.body.password;
    var hashedPassword = passwordHash.generate(password);

    console.log(result);
    if(result != null && password != null)
    {
    

    con.query(`SELECT email FROM users WHERE email = ?`, [email], function (err, result, fields) {
        if (err) throw err;
        if(result[0] == undefined )
        {
            var sql = `INSERT INTO users (email, password, isgoogle) VALUES (? , ?, ?)`;
            con.query(sql,[email, hashedPassword, '0'], function (err, result) {
                    if (err) throw err;
                    console.log("Regular User Added");
            });
            passCorr = true;

            Email_Cor = email;
            res.redirect('/');
        }
        else {
            passEmp = true;
            res.redirect('/');

        }
    });

    }else{
        passEmp = true;

        res.redirect('/');

    }

    
});

app.get('/logoutReg', (req, res) => {
    googleLogin = false;
    savedData = false;
    passCorr = false;
    logout = true;

    res.redirect('/');
});

app.get('/preview', (req, res) => {
    res.sendFile(path.join(__dirname+'/public/index.html'));

});

app.get('/logout', (req, res) => {
    passCorr = false;
logout = true;
    req.session = null;
    req.logout();
    googleData = "";
    googleLogin = false;
    savedData = false;
    res.redirect('/');

});

//#region Passport Google oAuth 2.0
passport.serializeUser(function(user, done) {
    /*
    From the user take just the id (to minimize the cookie size) and just pass the id of the user
    to the done callback
    PS: You dont have to do it like this its just usually done like this
    */
    done(null, user);
  });
  
passport.deserializeUser(function(user, done) {
    /*
    Instead of user this function usually recives the id 
    then you use the id to select the user from the db and pass the user obj to the done callback
    PS: You can later access this data in any routes in: req.user
    */
    done(null, user);
});

passport.use(new GoogleStrategy({
    clientID: "301770347830-sojpodpemipre048i2u000a52pfmr3nt.apps.googleusercontent.com",
    clientSecret: "UsVGjqTToveqr670hcCDCSB1",
    callbackURL: "http://localhost:8081/google/callback"
  },
  function(accessToken, refreshToken, profile, done) {
    /*
     use the profile info (mainly profile id) to check if the user is registerd in ur db
     If yes select the user and pass him to the done callback
     If not create the user and then select him and pass to callback
    */
    return done(null, profile);
  }
));

//#endregion

app.post('/img', function (req, res){
    var form = new formidable.IncomingForm();
    form.parse(req);

    form.on('fileBegin', function (name, file){
        file.path = __dirname + '/public/images/' + file.name;
        face_photo = './images/' + file.name;

    });

    form.on('file', function (name, file){
        console.log('Uploaded ' + file.name);
    });


    res.status(200);
});

//#region Json File

/*
app.get('/json', function (req, res){
    var form = new formidable.IncomingForm();
    form.parse(req);

    form.on('fileBegin', function (name, file){
        file.path = __dirname + '/public/' + file.name;

        var content = fs.readFileSync(file.name);
        jsonDict = JSON.parse(content);
        console.log(jsonDict.selected_interests);
        console.log(jsonDict);

    });

    form.on('file', function (name, file){
    });

   

    res.status(200);
});

*/
//#endregion

app.post("/zip",function(req,res){


    let firstname= req.body.firstname;
    let middlename= req.body.middlename;
    let lastname= req.body.lastname;

    let profession= req.body.profession;

    let introduction= req.body.introduction;

    let programs=  JSON.parse(req.body.programs);
    let program_dates=  JSON.parse(req.body.program_dates);
    let universities=  JSON.parse(req.body.universities);
    let degree_types=  JSON.parse(req.body.degree_types);

    let project_names = JSON.parse(req.body.project_names);
    let project_details = JSON.parse(req.body.project_details);
    let project_date = JSON.parse(req.body.project_date);

    let exp_names = JSON.parse(req.body.exp_names);
    let exp_titles = JSON.parse(req.body.exp_titles);

    let exp_details = JSON.parse(req.body.exp_details);
    let exp_date = JSON.parse(req.body.exp_date);

    let selected_skills = JSON.parse(req.body.selected_skills);
    let selected_interests = JSON.parse(req.body.selected_interests);

    let mobile_numb= req.body.mobile_numb;
    let email= req.body.email;

    let instagram= req.body.instagram;
    let facebook= req.body.facebook;
    let twitter= req.body.twitter;
    let linkedin= req.body.linkedin;
    let github= req.body.github;
    let youtube= req.body.youtube;
    let color_theme = req.body.color_theme;

    dict['firstname'] = firstname;
    dict['middlename'] = middlename;
    dict['lastname'] = lastname;

    dict['profession'] = profession;

    dict['introduction'] = introduction;

    dict['programs'] = programs;
    dict['program_dates'] = program_dates;
    dict['universities'] = universities;
    dict['degree_types'] = degree_types;

    dict['exp_names'] = exp_names;
    dict['exp_titles'] = exp_titles;
    dict['exp_details'] = exp_details;
    dict['exp_date'] = exp_date;

    dict['project_names'] = project_names;
    dict['project_details'] = project_details;
    dict['project_date'] = project_date;

    dict['selected_skills'] = selected_skills;
    dict['selected_interests'] = selected_interests;

    dict['mobile_numb'] = mobile_numb;
    dict['email'] = email;
    dict['instagram'] = instagram;
    dict['linkedin'] = linkedin;
    dict['twitter'] = twitter;
    dict['github'] = github;
    dict['facebook'] = facebook;
    dict['youtube'] = youtube;
    dict['color_theme'] = color_theme;


    

    let jsonContent = JSON.stringify(dict);
    console.log(jsonContent);

    if(googleAcc)
    {

        if(savedData == true)
        {
            var sql = `UPDATE userdata SET jsondata = ? WHERE email = ?` ;
            let que = [ jsonContent, googleData.emails[0]["value"]];
            con.query(sql,que,  function (err, result) {
                if (err) throw err;
                console.log("Data Added");
            });
        }

        if(savedData == false)
        {
            console.log(jsonContent);

            var sql = `INSERT INTO userdata (email, jsondata) VALUES (?,?)`;
            let que = [googleData.emails[0]["value"],  jsonContent];

            con.query(sql, que,function (err, result) {
                if (err) throw err;
                console.log(result);
            });
    
        }
    }else{
        if(savedData == true)
        {
            var sql = `UPDATE userdata SET jsondata = ? WHERE email = ?` ;
            let que = [ jsonContent, Email_Cor];
            con.query(sql,que,  function (err, result) {
                if (err) throw err;
                console.log("Data Added");
            });
        }

        if(savedData == false)
        {
            console.log(jsonContent);

            var sql = `INSERT INTO userdata (email, jsondata) VALUES (?,?)`;
            let que = [Email_Cor,  jsonContent];

            con.query(sql, que,function (err, result) {
                if (err) throw err;
                console.log(result);
            });
    
        }
    }
    

    fs.writeFile("./index.json", jsonContent, 'utf8', function (err) {
        if (err) {
            return console.log(err);
        }

        console.log("The file was saved!");
    }); 

   
    let Layout =Header(firstname,lastname) + 
                NavBar(firstname, middlename , lastname,programs,exp_names,project_names,selected_skills,selected_interests) + 
                HomeLayout1(firstname,profession,face_photo) + 
                About(face_photo,introduction);

                if( programs[0] != undefined)
                {
                    Layout += Education(programs,program_dates,universities,degree_types);

                }
                if( exp_names[0] != undefined)
                {
                    Layout += Experience(exp_titles,exp_names,exp_date,exp_details);

                }
                if( project_names[0] != undefined)
                {
                    Layout += Projects(project_names,project_details,project_date);

                }
                if( selected_skills[0] != undefined)
                {
                    Layout += Skills(selected_skills);

                }
                console.log(selected_interests[0]);
                console.log(selected_interests);

                if( selected_interests[0] != undefined)
                {
                    Layout += Interests(selected_interests);

                }
                
                Layout += Contact(firstname, middlename, lastname, mobile_numb, email, instagram, twitter, linkedin, github, youtube, facebook);

                


    //Home Layout
        fs.writeFile(`./public/index.html`,Layout,function (err) {
            if (err) throw err;
            console.log('Home Layout Submitted');
        });
        res.end();

    //#region Color Selector

        css_color = "";

        if(color_theme == 'red')
        {
            css_color = ':root{ --first-color: #f44040;  --second-color: #310e0e; }';

        }

        if(color_theme == 'orange')
        {
            css_color = ':root{ --first-color: #f48240;  --second-color: #311f0e; }';

        }

        if(color_theme == 'yellow')
        {
            css_color = ':root{ --first-color: #f4f140;  --second-color: #31300e; }';

        }

        if(color_theme == 'green')
        {
            css_color = ':root{ --first-color: #40f440;  --second-color: #0f310e; }';

        }

        if(color_theme == 'cyan')
        {
            css_color = ':root{ --first-color: #40f4f4;  --second-color: #0e3031; }';

        }

        if(color_theme == 'blue')
        {
            css_color = ':root{ --first-color: #4070F4;  --second-color: #0E2431; }';
        }

        if(color_theme == 'purple')
        {
            css_color = ':root{ --first-color: #b240f4;  --second-color: #270e31; }';

        }



        fs.appendFile('./public/css/styles.css', css_color, function (err) {
            if (err) throw err;
            console.log('Saved!');
          });

    //#endregion

    var output = fs.createWriteStream('target.zip');
    var archive = archiver('zip');

    output.on('close', function () {
        console.log('Zip Created');
    });
    
    archive.on('error', function(err){
        throw err;
    });
    
    archive.pipe(output);
    
    archive.directory('public/', 'public');
    archive.directory('css/', 'css');

    archive.finalize();

    
      
});

app.get('/downloadFile/', function (req, res) {

    res.download('./target.zip');

    const directory = 'public/images/';

    fs.readdir(directory, (err, files) => {
        if (err) throw err;

        for (const file of files) {
            fs.unlink(path.join(directory, file), err => {
                    if (err) throw err;
            });
        }
    });
});

let server = app.listen(8081, function () {
    let host = server.address().address
    let port = server.address().port
    console.log(host + ": "+port);
});

//#region Website Layout Functions
function Header(firstname, lastname) {
    layout1 = '<html lang="en">'+
    '<head>'+
        '<meta charset="UTF-8">'+
        '<meta name="viewport" content="width=device-width, initial-scale=1.0">'+

        '<link rel="stylesheet" href="css/styles.css">'+

        "<link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>"+

        '<title>'+ firstname + " " + lastname + '</title>'+
    '</head>'+
    '<body>';

    return layout1;
}

function NavBar(firstname, middlename , lastname,programs,exp_names,project_names,selected_skills,selected_interests) {
    layout1 = '<header class="l-header">' +
    '<nav class="nav bd-grid">' +
        '<div>'+
            '<a href="#" class="nav__logo">'+ firstname + " " + middlename + " " + lastname + '</a>'+
        '</div>'+

        '<div class="nav__menu" id="nav-menu">'+
            '<ul class="nav__list">'+
                '<li class="nav__item"><a href="#home" class="nav__link active">Home</a></li>'+
                '<li class="nav__item"><a href="#about" class="nav__link">About</a></li>';

                if( programs[0] != undefined)
                {
                    layout1 +='<li class="nav__item"><a href="#education" class="nav__link">Education</a></li>';
                }
                if( exp_names[0] != undefined)
                {
                    layout1 +='<li class="nav__item"><a href="#experience" class="nav__link">Experience</a></li>';
                }
                if( project_names[0] != undefined)
                {
                    layout1 +='<li class="nav__item"><a href="#projects" class="nav__link">Projects</a></li>';
                }
                if( selected_skills[0] != undefined)
                {
                    layout1 +='<li class="nav__item"><a href="#skills" class="nav__link">Skills</a></li>';
                }
                if( selected_interests[0] != undefined)
                {
                    layout1 +='<li class="nav__item"><a href="#interests" class="nav__link">Interests</a></li>';
                }

                
                layout1 += '<li class="nav__item"><a href="#contact" class="nav__link">Contact</a></li>'+
            '</ul>'+
        '</div>'+

        '<div class="nav__toggle" id="nav-toggle">'+
            '<i class="bx bx-menu"></i>'+
        '</div>'+
    '</nav>'+
'</header>';

    return layout1;
}

function HomeLayout1(firstname, profession,image_loca) {
    layout1 = '<section class="home bd-grid" id="home">' +
                '<div class="home__data">'+
                    "<h1 class='home__title'>Hi,<br>I'am <span class='home__title-color'>" + firstname + "</span><br>" + profession + "</h1>" +

                    '<a href="#contact" class="button">Contact</a></div>' +

                

                '<div class="home__img">'+
                    '<img src= "'+ image_loca +'" alt="">' +
                '</div>'+
            '</section>';

    return layout1;
}

function About(image_loca, introduction) {
    layout1 = '<section class="about section " id="about">'+
    '<h2 class="section-title">About</h2>'+

    '<div class="about__container bd-grid">'+
        '<div class="about__img">'+
            '<img src="'+ image_loca +'" alt="">'+
        '</div>'+
        
            '<div>'+
                '<h2 class="about__subtitle">' +introduction+'</h2>'+
                '<p class="about__text"></p>'      +
            '</div>'                 +          
        '</div>'+
    '</section>';

    return layout1;
}

function Education(programs,program_dates,universities,degree_types) {
    let layout1 =
    '<section class="education section" id="education">' +
       '<h2 class="section-title">Education</h2>' +

    '<div class="skills__container bd-grid">';

    for (i = 0; i < programs.length; i++) {

       layout1 += '<div class="skills__data">' +
                '<div class="skills__names">' +
                    '<span class="skills__name">'+ degree_types[i] + " in " + programs[i] +'</span> <br>' +
                    
                '</div>'+ 
                '<div class="skills__names">' +
                    '<span class="skills__name">'+ universities[i] +'</span> <br>' +
                    
                '</div>'+ 
                '<span class="skills__date">'+ program_dates[i] +'</span>'+
    
              
            '</div>';
    }

    layout1 +=   '</div>' +
   '</section>';

   return layout1;
}

function Experience(exp_title,exp_names,exp_date,exp_details){
     let layout1 =
     '<section class="experience section" id="experience">' +
        '<h2 class="section-title">Experience</h2>' +

     '<div class="skills__container bd-grid">';

     for (i = 0; i < exp_title.length; i++) {

        layout1 += '<div class="skills__data">' +
                 '<div class="skills__names">' +
                     '<span class="skills__name">'+ exp_title[i] +'</span> <br>' +
                     
                 '</div>'+ 
                 '<div class="skills__names">' +
                     '<span class="skills__name">'+ exp_names[i] +'</span> <br>' +
                     
                 '</div>'+ 
                 '<span class="skills__date">'+ exp_date[i] +'</span>'+
                 '<br>'+
                 '<p>'+ exp_details[i] +'</p>'+
             '</div>';
     }

     layout1 +=   '</div>' +
    '</section>';

    return layout1;
}

function Projects(project_names,project_details,project_date){
    let layout1 =
    '<section class="projects section" id="projects">' +
       '<h2 class="section-title">Projects</h2>' +

    '<div class="skills__container bd-grid">';

    for (i = 0; i < project_names.length; i++) {

       layout1 += '<div class="skills__data">' +
                '<div class="skills__names">' +
                    '<span class="skills__name">'+ project_names[i] +'</span> <br>' +
                    
                '</div>'+ 
                '<span class="skills__date">'+ project_date[i] +'</span>'+
                '<br>'+
                '<p>'+ project_details[i] +'</p>'+
            '</div>';
    }

    layout1 +=   '</div>' +
   '</section>';

   return layout1;
}

function Skills(selected_skills){
    let layout1 =
    '<section class="skills section" id="skills">' +
       '<h2 class="section-title">Skills</h2>' +

    '<div class="skills__container bd-grid">';

    for (i = 0; i < selected_skills.length; i++) {

       layout1 += '<div class="skills__data">' +
                '<div class="skills__names">' +
                    '<span class="skills__name">'+ selected_skills[i] +'</span> <br>' +
                    
                '</div>'+ 
                
            '</div>';
    }

    layout1 +=   '</div>' +
   '</section>';

   return layout1;
}

function Interests(selected_interests){
    let layout1 =
    '<section class="interests section" id="interests">' +
       '<h2 class="section-title">Interests</h2>' +

    '<div class="skills__container bd-grid">';

    for (i = 0; i < selected_interests.length; i++) {

       layout1 += '<div class="skills__data">' +
                '<div class="skills__names">' +
                    '<span class="skills__name">'+ selected_interests[i] +'</span> <br>' +
                    
                '</div>'+ 
                
            '</div>';
    }

    layout1 +=   '</div>' +
   '</section>';

   return layout1;
}

function Contact(firstname, middlename, lastname, mobile_numb, email, instagram, twitter, linkedin, github, youtube, facebook){
    let layout = 
    '<section class="contact section" id="contact">' +
                '<h2 class="section-title">Contact</h2>'+

                '<div class="contact__container bd-grid">'+
                    '<form action="" class="contact__form">'+
                        '<input type="text" placeholder="Name" class="contact__input">'+
                        '<input type="mail" placeholder="Email" class="contact__input">'+
                        '<textarea name="" id="" cols="0" rows="10" class="contact__input"></textarea>'+
                        '<input type="button" value="Send" class="contact__button button">'+
                    '</form>'+
                '</div>'+
            '</section>'+
            '<footer class="footer">'+
            '<p class="footer__title">'+ firstname + " " + middlename + " " + lastname + '</p>'+
            '<div class="footer__social">';

            if(mobile_numb != '')
            {
                layout +=  '<a href="#" class="footer__icon">'+mobile_numb+'</a> <br> <br>';
            }

            if(email != '')
            {
                layout +=  '<a href="#" class="footer__icon">'+email+'</a> <br> <br>';
            }

            if(instagram != '')
            {
                layout += '<a href='+instagram+' class="footer__icon"><i class="bx bxl-instagram" ></i></a>';
            }

            if(twitter != '')
            {
                layout += '<a href='+twitter+' class="footer__icon"><i class="bx bxl-twitter" ></i></a>';
            }

            if(linkedin != '')
            {
                layout += '<a href='+linkedin+' class="footer__icon"><i class="bx bxl-linkedin" ></i></a>';
            }

            if(github != '')
            {
                layout += '<a href='+github+' class="footer__icon"><i class="bx bxl-github" ></i></a>';
            }
            
            if(youtube != '')
            {
                layout += '<a href='+youtube+' class="footer__icon"><i class="bx bxl-youtube" ></i></a>';
            }
            
            if(facebook != '')
            {
                layout += '<a href='+facebook+' class="footer__icon"><i class="bx bxl-facebook" ></i></a>';
            }

            layout += '</div>'+
            '<p>&#169; 2020 copyright all right reserved</p>'+
            '</footer>'+

            '</body>'+
            '</html>';
            
            return layout;
}
 
//#endregion

//#region WebSockets
let ws= new webSocket.Server({port:8080});

ws.on("connection",function(thisWs){


    if(passEmp == true)
    {
        thisWs.send(`passEmp`);
        passEmp = false;
    }

    if(passCorr == true)
    {
        
        if(googleAcc == false)
        {
            if(savedData == true)
            {
              
                thisWs.send(`passCorr:${Email_Cor}:1`);
    
            } else {
                thisWs.send(`passCorr:${Email_Cor}:0`);
    
            }
        }
    }

    if(passInc == true)
    {
        thisWs.send(`passInc`);
        passInc = false;

    }
    
    if(googleLogin == true)
    {
        if(savedData == true)
        {
            /*
            con.query(`SELECT email FROM data WHERE email ='${googleData.emails[0]["value"]}'`, function (err, result, fields) {
                if (err) throw "does not exist";
                //result = JSON.stringify(result)
                console.log(result[0].email + "WEE");
    
                if(result[0].email == googleData.emails[0]["value"])
                {
                    thisWs.send(`googleLogin:${googleData.displayName}:1`);
                }
                else {
                    thisWs.send(`googleLogin:${googleData.displayName}:0`);
                }
               
            });
            */
           thisWs.send(`googleLogin:${googleData.displayName}:1`);

        } else {
            thisWs.send(`googleLogin:${googleData.displayName}:0`);

        }
    
    }

    
    if(googleLogin == false && passCorr == false)    
    {
        thisWs.send(`revert`);

    }
    thisWs.on("message",function(msg){
        let splitMsg= msg.split(":");
        let jsonData = "";
        

        if(splitMsg[0]=="loadusers"){
            console.log(logout);
            if(googleAcc == true)
            {
            con.query(`SELECT * FROM userdata WHERE email =?`, [googleData.emails[0]["value"]], function (err, result, fields) {
                if (err) throw err;
                jsonData = result[0].jsondata;
                                jsonData = JSON.parse(jsonData);

                                thisWs.send(`writemessage:
                                ${jsonData.firstname}:
                                ${jsonData.middlename}:
                                ${jsonData.lastname}:
                                ${jsonData.profession}:
                                ${jsonData.introduction}:
                                ${jsonData.project_names}:
                                ${jsonData.project_details}:
                                ${jsonData.project_date}:
                                ${jsonData.programs}:
                                ${jsonData.program_dates}:
                                ${jsonData.universities}:
                                ${jsonData.degree_types}:
                                ${jsonData.exp_names}:
                                ${jsonData.exp_titles}:
                                ${jsonData.exp_details}:
                                ${jsonData.exp_date}:
                                ${jsonData.selected_skills}:
                                ${jsonData.selected_interests}:
                                ${jsonData.mobile_numb}:
                                ${jsonData.email}:
                                ${jsonData.instagram}:
                                ${jsonData.linkedin}:
                                ${jsonData.twitter}:
                                ${jsonData.github}:
                                ${jsonData.facebook}:
                                ${jsonData.youtube}:
                                ${jsonData.color_theme}:`);
                                
    
            });
            } else {
                if(logout == false)
                {
                con.query(`SELECT * FROM userdata WHERE email =?`, [Email_Cor], function (err, result, fields) {
                    if (err) throw err;
                    jsonData = result[0].jsondata;
                    console.log(jsonData + "W");

                    if(jsonData != '') {
                        jsonData = JSON.parse(jsonData);

                    
    
                                    thisWs.send(`writemessage:
                                    ${jsonData.firstname}:
                                    ${jsonData.middlename}:
                                    ${jsonData.lastname}:
                                    ${jsonData.profession}:
                                    ${jsonData.introduction}:
                                    ${jsonData.project_names}:
                                    ${jsonData.project_details}:
                                    ${jsonData.project_date}:
                                    ${jsonData.programs}:
                                    ${jsonData.program_dates}:
                                    ${jsonData.universities}:
                                    ${jsonData.degree_types}:
                                    ${jsonData.exp_names}:
                                    ${jsonData.exp_titles}:
                                    ${jsonData.exp_details}:
                                    ${jsonData.exp_date}:
                                    ${jsonData.selected_skills}:
                                    ${jsonData.selected_interests}:
                                    ${jsonData.mobile_numb}:
                                    ${jsonData.email}:
                                    ${jsonData.instagram}:
                                    ${jsonData.linkedin}:
                                    ${jsonData.twitter}:
                                    ${jsonData.github}:
                                    ${jsonData.facebook}:
                                    ${jsonData.youtube}:
                                    ${jsonData.color_theme}:`);
                    }
        
                });
            }
            }
                
              

        }
    })
})

//#endregion