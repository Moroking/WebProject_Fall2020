    let wsUrl= "ws://localhost:8080";
    let connection= new WebSocket(wsUrl);

    var color_theme = "";
    var exp_names = [];
    var exp_titles = [];
    var exp_details = [];
    var exp_date = [];

    var project_names = [];
    var project_details = [];
    var project_date = [];

    var programs = [];
    var program_dates = [];
    var universities = [];
    var degree_types = [];

    var selected_skills = [];
    var selected_interests = [];

    var downloadable = false;

    var images = false;
    
    connection.onopen=function(e){
        console.log("connected");
        let msg= e.data;
        
    }

    connection.onmessage=function(e){
        let msg= e.data;
        let splitMsg= msg.split(":");
        console.log(splitMsg[0]);
        //let list= splitMsg[3].split(",");
        console.log(splitMsg);

        if(splitMsg[0] == 'passEmp')
        {
            alert("Email Exists");
        }

        if(splitMsg[0] == 'passCorr')
        {
            document.getElementById("google_user").innerHTML = "Welcome " + splitMsg[1];
            console.log("LALALALA");

            $('#google_user').show();
            $('#google_user_logout').hide();
            $('#reg_user_logout').show();
            $('#login_user').hide();
            $('#register_user').hide();

            if(splitMsg[2] == '1')
            {
                let result = confirm(splitMsg[1] +", Do you want to load your previous data?");

                if(result)
                {
                    connection.send(`loadusers`);
                }
            }

        }

        if(splitMsg[0] == 'passInc')
        {
            alert("Password or Email is incorrect");

        }

        if(splitMsg[0] == 'googleLogin')
        {
            document.getElementById("google_user").innerHTML = "Welcome " + splitMsg[1];

            $('#google_user').val('Welcome Maurice');
            $('#google_user').show();
            $('#google_user_logout').show();
            $('#reg_user_logout').hide();

            $('#login_user').hide();
            $('#register_user').hide();

            if(splitMsg[2] == '1')
            {
                let result = confirm(splitMsg[1] +", Do you want to load your previous data?");

                if(result)
                {
                    connection.send(`loadusers`);
                }
            }

            


        }

        if(splitMsg[0] == 'revert')
        {
            console.log("it works 2");
            //document.getElementById("google_user").innerHTML = "Welcome " + splitMsg[1];

            $('#google_user').hide();
            $('#google_user_logout').hide();
            $('#reg_user_logout').hide();

            $('#login_user').show();
            $('#register_user').show();

        }

        if(splitMsg[0]=="writemessage"){

            $('#firstname').val(splitMsg[1].trim());
            $('#middlename').val(splitMsg[2].trim());
            $('#lastname').val(splitMsg[3].trim());

            $('#profession').val(splitMsg[4].trim());

            $('#introduction').val(splitMsg[5].trim());


            let project_names_SM = splitMsg[6].split(",");
            let project_details_SM = splitMsg[7].split(",");
            let project_date_SM = splitMsg[8].split(",");
            

        if(project_names_SM[0].trim() != '')
        {

            for (i in project_names_SM) {
                
                var tr = document.createElement("tr");

                var td_name = document.createElement("td");
                td_name.innerText = project_names_SM[i].trim();
    
                var td_details = document.createElement("td"); 
                td_details.innerText = project_details_SM[i].trim();
                
                var td_date = document.createElement("td"); 
                td_date.innerText = project_date_SM[i].trim();
                
                var bt = [];
                bt.push(project_names_SM[i].trim());
                bt.push(project_details_SM[i].trim());
                bt.push(project_date_SM[i].trim());
                
                var button = document.createElement("input");
                button.type="button";
                button.value="X";
                button.id="remove";
                button.className= bt; 
                tr.append(td_name);
                tr.append(td_details);
                tr.append(td_date);
                tr.append(button);

                project_names.push(project_names_SM[i].trim());
                project_details.push(project_details_SM[i].trim());
                project_date.push(project_date_SM[i].trim());
                
                $("#projects_table").append(tr);
    
                
                $("#end_project_date").val('');
                $("#start_project_date").val('');
                $("#end_project_date_btn").prop('checked', true);
                $("#end_project_ongoing_btn").prop('checked', false);
                $("#end_project_date").show().fadeIn(100);
    
                $("#project_details").val('');
                $("#project_name").val('');
    

            }
        }

            let programs_SM = splitMsg[9].split(",");
            let program_dates_SM = splitMsg[10].split(",");
            let universities_SM = splitMsg[11].split(",");
            let degree_types_SM = splitMsg[12].split(",");
           

        if(programs_SM[0].trim() != '')
        {
            for (i in programs) {
                
                var tr = document.createElement("tr");

                var td_type = document.createElement("td");
                td_type.innerText = degree_types_SM[i].trim();

                var td_program = document.createElement("td"); 
                td_program.innerText = programs_SM[i].trim();
    
                var td_university = document.createElement("td"); 
                td_university.innerText = universities_SM[i].trim();

                var td_date = document.createElement("td"); 
                td_date.innerText = program_dates_SM[i].trim();
    
                var bt = [];
                bt.push(degree_types_SM[i].trim());
                bt.push(programs_SM[i].trim());
                bt.push(universities_SM[i].trim());
                bt.push(program_dates_SM[i].trim());

                programs.push(programs_SM[i].trim());
                program_dates.push(program_dates_SM[i].trim());
                universities.push(universities_SM[i].trim());
                degree_types.push(degree_types_SM[i].trim());

                var button = document.createElement("input");
                button.type="button";
                button.value="X";
                button.id="remove";
                button.className= bt; 
    
                tr.append(td_type);
                tr.append(td_program);
                tr.append(td_university);
                tr.append(td_date);

                tr.append(button);
    
                $("#program_table").append(tr);
                

            }
        }

            let exp_names_SM = splitMsg[13].split(",");
            let exp_titles_SM = splitMsg[14].split(",");
            let exp_details_SM = splitMsg[15].split(",");
            let exp_date_SM = splitMsg[16].split(",");
            

        if(exp_names_SM[0].trim() != '')
        {

            for (i in exp_names) {
                
                var tr = document.createElement("tr");

                var td_name = document.createElement("td");
                td_name.innerText = exp_names_SM[i].trim();

                var td_title = document.createElement("td");
                td_title.innerText = exp_titles_SM[i].trim();
    
                var td_details = document.createElement("td"); 
                td_details.innerText = exp_details_SM[i].trim();
                
                var td_date = document.createElement("td"); 
                td_date.innerText = exp_date_SM[i].trim();
                
    
                var bt = [];
                bt.push(exp_names_SM[i].trim());
                bt.push(exp_titles_SM[i].trim());

                bt.push(exp_details_SM[i].trim());
                bt.push(exp_date_SM[i].trim());

                exp_names.push(exp_names_SM[i].trim());
                exp_titles.push(exp_titles_SM[i].trim());
                exp_details.push(exp_details_SM[i].trim());
                exp_date.push(exp_date_SM[i].trim());
                
                var button = document.createElement("input");
                button.type="button";
                button.value="X";
                button.id="remove";
                button.className= bt; 
                tr.append(td_name);
                tr.append(td_title);

                tr.append(td_details);
                tr.append(td_date);
                tr.append(button);
                
                $("#exp_table").append(tr);
    
               
            }
        }

            let selected_skills_SM = splitMsg[17].split(",");

        if(selected_skills_SM[0].trim() != '')
        {

            for(i in selected_skills_SM) {

                var div_minicard = document.createElement("div");
                div_minicard.className = "minicard";
    
                var div_container = document.createElement("div");
                div_container.className = "container";
                div_container.innerText = selected_skills_SM[i].trim();
                
                selected_skills.push(selected_skills_SM[i].trim());

                var button = document.createElement("input");
                button.type="button";
                button.value="X";
                button.id="remove";
                button.className= selected_skills_SM[i].trim(); 
    
                div_container.append(button);
    
                div_minicard.append(div_container);
                
                
                $("#skill_list").append(div_minicard);
    
                
            }
        }

            let selected_interests_SM = splitMsg[18].split(",");

        if(selected_interests_SM[0].trim() != '')
        {
    
            for(i in selected_interests_SM) {

                var div_minicard = document.createElement("div");
                div_minicard.className = "minicard";
    
                var div_container = document.createElement("div");
                div_container.className = "container";
                div_container.innerText = selected_interests_SM[i].trim();
                
                selected_interests.push(selected_interests_SM[i].trim());

                var button = document.createElement("input");
                button.type="button";
                button.value="X";
                button.id="remove";
                button.className= selected_interests_SM[i].trim(); 
    
                div_container.append(button);
    
                div_minicard.append(div_container);
                
                
                $("#int_list").append(div_minicard);
    
                
            }
        }

        $('#mobile_numb').val(splitMsg[19].trim());
        $('#email').val(splitMsg[20].trim());
        $('#instagram').val(splitMsg[21].trim());
        $('#linkedin').val(splitMsg[22].trim());
        $('#twitter').val(splitMsg[23].trim());
        $('#github').val(splitMsg[24].trim());
        $('#facebook').val(splitMsg[25].trim());
        $('#youtube').val(splitMsg[26].trim());


        if(splitMsg[27].trim() == 'red')
        {
            $("#input[name=color_btn]").prop('checked', false);
            $("#red").prop('checked', true);
            color_theme = "red";

        }
        if(splitMsg[27].trim() == 'orange')
        {
            $("#input[name=color_btn]").prop('checked', false);
            $("#orange").prop('checked', true);
            color_theme = "orange";
        }

        if(splitMsg[27].trim() == 'yellow')
        {
            $("#input[name=color_btn]").prop('checked', false);
            $("#yellow").prop('checked', true);
            color_theme = "yellow";
        }

        if(splitMsg[27].trim() == 'green')
        {
            $("#input[name=color_btn]").prop('checked', false);
            $("#green").prop('checked', true);
            color_theme = "green";
        }
        if(splitMsg[27].trim() == 'cyan')
        {
            $("#input[name=color_btn]").prop('checked', false);
            $("#cyan").prop('checked', true);
            color_theme = "cyan";
        }
        if(splitMsg[27].trim() == 'blue')
        {
            $("#input[name=color_btn]").prop('checked', false);
            $("#blue").prop('checked', true);
            color_theme = "blue";        }
        if(splitMsg[27].trim() == 'purple')
        {
            $("#input[name=color_btn]").prop('checked', false);
            $("#purple").prop('checked', true);
            color_theme = "purple";
        }

        }
    }

    $('#google_user').hide();

    
    $("#preview").click(function(){
        window.open("http://localhost:8081/preview");
    });

    
    $("#downloadSection").hide();
    $("#preview").hide();

    $("#bt_post_json").hide();
    $("#bt_post_jsonget").hide();

    $("#info_btn").click(function(){
        $("#info").slideToggle(200);
    });

    $("#name_btn").click(function(){
        $("#namee").slideToggle(200);
    });

    $("#register_user").click(function(){
        $("#signup").show();
    });

    $("#login_user").click(function(){
        $("#login").show();
    });

    $("#close_log").click(function(){
        $("#login").hide();
    });

    $("#close_reg").click(function(){
        $("#signup").hide();
    });
  

    //#region  Color Theme

    $("#red").click(function(){
        $("#input[name=color_btn]").prop('checked', false);
        $("#red").prop('checked', true);
        color_theme = "red";
    });

    $("#orange").click(function(){
        $("#input[name=color_btn]").prop('checked', false);
        $("#orange").prop('checked', true);
        color_theme = "orange";

    });

    $("#yellow").click(function(){
        $("#input[name=color_btn]").prop('checked', false);
        $("#yellow").prop('checked', true);
        color_theme = "yellow";

    });

    $("#green").click(function(){
        $("#input[name=color_btn]").prop('checked', false);
        $("#green").prop('checked', true);
        color_theme = "green";

    });

    $("#cyan").click(function(){
        $("#input[name=color_btn]").prop('checked', false);
        $("#cyan").prop('checked', true);
        color_theme = "cyan";

    });

    $("#blue").click(function(){
        $("#input[name=color_btn]").prop('checked', false);
        $("#blue").prop('checked', true);
        color_theme = "blue";

    });

    $("#purple").click(function(){
        $("#input[name=color_btn]").prop('checked', false);
        $("#purple").prop('checked', true);
        color_theme = "purple";

    });

    //#endregion

    //#region Experience Info Section

    $("#end_exp_date").show().fadeIn(100);
    $("#end_exp_btn").prop('checked', true);
    $("#end_exp_btn").prop('checked', false);

    $("#exp_btn").click(function(){ //adding to the achievments 
        if($("#exp_name").val() != '' && $("#exp_title").val() != '' && $("#exp_details").val() != '' && $("#start_exp_date").val() != '' && ($("#end_exp_date").val() != '' || $("#end_exp_ongoing_btn").is(':checked')))
        {
            $("#exp_check").text("");
            $("#exp_check").css("color","red");

            var tr = document.createElement("tr");

            var td_name = document.createElement("td");
            td_name.innerText = $("#exp_name").val();

            var td_title = document.createElement("td");
            td_title.innerText = $("#exp_title").val();

            var td_details = document.createElement("td"); 
            td_details.innerText = $("#exp_details").val();
            
            var td_date = document.createElement("td"); 
            if($("#end_exp_date").val() != '')
            {
                td_date.innerText = $("#start_exp_date").val() + " To " + $("#end_exp_date").val();
            }else 
            {
                td_date.innerText = $("#start_exp_date").val() + " To " + $("#end_exp_ongoing_btn").val();
            }

            var bt = [];
            bt.push($("#exp_name").val());
            bt.push($("#exp_title").val());

            bt.push($("#exp_details").val());
            bt.push(td_date.innerText);
            
            var button = document.createElement("input");
            button.type="button";
            button.value="X";
            button.id="remove";
            button.className= bt; 
            tr.append(td_name);
            tr.append(td_title);
            tr.append(td_details);
            tr.append(td_date);
            tr.append(button);
            
            $("#exp_table").append(tr);

            
            exp_names.push($("#exp_name").val());
            exp_titles.push($("#exp_title").val());

            exp_details.push($("#exp_details").val());
            exp_date.push(td_date.innerText);
            $("#end_exp_date").val('');
            $("#start_exp_date").val('');
            $("#end_exp_date_btn").prop('checked', true);
            $("#end_exp_ongoing_btn").prop('checked', false);
            $("#end_exp_date").show().fadeIn(100);

            $("#exp_details").val('');
            $("#exp_name").val('');

        } else {
            $("#exp_check").text("Fill All To Add Another");
            $("#exp_check").css("color","red"); 
        }
    });

    document.querySelector("#exp_table").addEventListener("click",(event)=>{
        if(event.target.id=="remove")
        { 
            var bt_arr = event.target.className.split(",");
            exp_names = arrayRemove(exp_names, bt_arr[0]);
            exp_titles = arrayRemove(exp_titles, bt_arr[1]);
            exp_details = arrayRemove(exp_details, bt_arr[2]);
            exp_date = arrayRemove(exp_date, bt_arr[3]);
            console.log(exp_names);


            event.target.parentNode.remove();
        }
    });
    //#endregion

    //#region Projects Info Section
    
    $("#end_project_date").show().fadeIn(100);
    $("#end_project_date_btn").prop('checked', true);
    $("#end_project_ongoing_btn").prop('checked', false);
    $("#projects_btn").click(function(){ 
        console.log($("#project_details").val());//adding to the achievments 
        if($("#project_name").val() != '' && $("#project_details").val() != '' && $("#start_project_date").val() != '' && ($("#end_project_date").val() != '' || $("#end_project_ongoing_btn").is(':checked')))
        {
            $("#proj_check").text("");
            $("#proj_check").css("color","red");

            var tr = document.createElement("tr");

            var td_name = document.createElement("td");
            td_name.innerText = $("#project_name").val();

            var td_details = document.createElement("td"); 
            td_details.innerText = $("#project_details").val();
            
            var td_date = document.createElement("td"); 
            if($("#end_project_date").val() != '')
            {
                td_date.innerText = $("#start_project_date").val() + " To " + $("#end_project_date").val();
            }else 
            {
                td_date.innerText = $("#start_project_date").val() + " To " + $("#end_project_ongoing_btn").val();
            }

            var bt = [];
            bt.push($("#project_name").val());
            bt.push($("#project_details").val());
            bt.push(td_date.innerText);
            
            var button = document.createElement("input");
            button.type="button";
            button.value="X";
            button.id="remove";
            button.className= bt; 
            tr.append(td_name);
            tr.append(td_details);
            tr.append(td_date);
            tr.append(button);
            
            $("#projects_table").append(tr);

            
            project_names.push($("#project_name").val());
            project_details.push($("#project_details").val());
            project_date.push(td_date.innerText);
            console.log(project_names);
            $("#end_project_date").val('');
            $("#start_project_date").val('');
            $("#end_project_date_btn").prop('checked', true);
            $("#end_project_ongoing_btn").prop('checked', false);
            $("#end_project_date").show().fadeIn(100);

            $("#project_details").val('');
            $("#project_name").val('');

        } else {
            $("#proj_check").text("Fill All To Add Another");
            $("#proj_check").css("color","red"); 
        }
    });

    document.querySelector("#projects_table").addEventListener("click",(event)=>{
        if(event.target.id=="remove")
        { 
            var bt_arr = event.target.className.split(",");
            project_names = arrayRemove(project_names, bt_arr[0]);
            project_details = arrayRemove(project_details, bt_arr[1]);
            project_date = arrayRemove(project_date, bt_arr[2]);
           
            console.log(bt_arr[0]);

            event.target.parentNode.remove();
        }
    });
    
    $("#end_project_date_btn").click(function(){
        $("#end_project_date").show().fadeIn(200);
        $("#end_project_ongoing_btn").prop('checked', false);
        $("#end_project_date").val('');
    });

    $("#end_project_ongoing_btn").click(function(){
        $("#end_project_date_btn").prop('checked', false);
        
        $("#end_project_date").hide().fadeOut(200);
    });

    //#endregion

    //#region Programs Info Section

    $("#program_btn").click(function(){ //add another major or minor
        if($("#program").val() != '' && $("#university").val() != '' && $("#degree_type").val() != 'Select' && $("#start_program_date").val() != '' && ($("#end_program_date").val() != '' || $("#end_program_ongoing_btn").is(':checked')))
        {
            $("#prof_check").text("");
            $("#prof_check").css("color","red");

            var tr = document.createElement("tr");

            var td_type = document.createElement("td");
            td_type.innerText = $("#degree_type").val();
            var td_program = document.createElement("td"); 
            td_program.innerText = $("#program").val();

            var td_university = document.createElement("td"); 
            td_university.innerText = $("#university").val();

            var td_date = document.createElement("td"); 
            if($("#end_program_date").val() != '')
            {
                td_date.innerText = $("#start_program_date").val() + " - " + $("#end_program_date").val();
            }else 
            {
                td_date.innerText = $("#start_program_date").val() + " - " + $("#end_program_ongoing_btn").val();
            }

            var bt = [];
            bt.push($("#program").val());
            bt.push($("#university").val());
            bt.push($("#degree_type").val());
            bt.push(td_date.innerText);

            var button = document.createElement("input");
            button.type="button";
            button.value="X";
            button.id="remove";
            button.className= bt; 

            tr.append(td_type);
            tr.append(td_program);
            tr.append(td_university);
            tr.append(td_date);

            tr.append(button);

            $("#program_table").append(tr);
            
            programs.push($("#program").val());
            universities.push($("#university").val());
            degree_types.push($("#degree_type").val());
            program_dates.push(td_date.innerText);

            console.log(programs[$("#program").val()]);
            $("#degree_type").val("Select");
            $("#program").val('');
            $("#university").val('');
            $("#end_program_date").val('');
            $("#start_program_date").val('');
            $("#end_program_date_btn").prop('checked', true);
            $("#end_program_ongoing_btn").prop('checked', false);
            $("#end_program_date").show().fadeIn(100);

        } else {
            $("#prof_check").text("Fill All To Add Another");
            $("#prof_check").css("color","red"); 
        }
    });

    document.querySelector("#program_table").addEventListener("click",(event)=>{
        if(event.target.id=="remove")
        {
            var bt_arr = event.target.className.split(",");
            programs = arrayRemove(programs, bt_arr[0]);
            universities = arrayRemove(universities, bt_arr[1]);
            degree_types = arrayRemove(degree_types, bt_arr[2]);
            program_dates = arrayRemove(program_dates, bt_arr[3]);
            console.log(bt_arr);
            console.log(programs);

            event.target.parentNode.remove();
        }
    });
    
    
    //#endregion

    //#region Skills Section
   

    
    
    $("#skill_btn").click(function(){ //adding to the achievments 
        if($("#skill").val() != '' )
        {
            $("#sk_check").text("");
            $("#sk_check").css("color","red");

            
            var div_minicard = document.createElement("div");
            div_minicard.className = "minicard";

            var div_container = document.createElement("div");
            div_container.className = "container";
            div_container.innerText = $("#skill").val(); 
            
            
            var button = document.createElement("input");
            button.type="button";
            button.value="X";
            button.id="remove";
            button.className= $("#skill").val(); 

            div_container.append(button);

            div_minicard.append(div_container);
            
            
            $("#skill_list").append(div_minicard);

            
            selected_skills.push($("#skill").val());
            console.log(selected_skills);

            $("#skill").val('');

        } else {
            $("#sk_check").text("Fill All To Add Another");
            $("#sk_check").css("color","red"); 
        }
    });

    document.querySelector("#skill_list").addEventListener("click",(event)=>{
        if(event.target.id=="remove")
        { 
            selected_skills = arrayRemove(selected_skills, event.target.className);
            event.target.parentNode.parentNode.remove();
            console.log(selected_skills);
        }
    });

    //#endregion

    $("#contact_btn").click(function(){
        var other_contacts = $("#other_contacts").val();
        $("#contact_menu").append('<div class="card"><div class="container">' + other_skills + '<input type="checkbox" name="skills" value=' + other_skills +  '></div></div>');
    });


    //#region Interests List Section
    $("#int_btn").click(function(){ //adding to the achievments 
        if($("#interest").val() != '' )
        {
            $("#int_check").text("");
            $("#int_check").css("color","red");

            
            var div_minicard = document.createElement("div");
            div_minicard.className = "minicard";

            var div_container = document.createElement("div");
            div_container.className = "container";
            div_container.innerText = $("#interest").val(); 
            
            
            var button = document.createElement("input");
            button.type="button";
            button.value="X";
            button.id="remove";
            button.className= $("#interest").val(); 

            div_container.append(button);

            div_minicard.append(div_container);
            
            
            $("#int_list").append(div_minicard);

            
            selected_interests.push($("#interest").val());
            console.log(selected_interests);

            $("#interest").val('');

        } else {
            $("#int_check").text("Fill All To Add Another");
            $("#int_check").css("color","red"); 
        }
    });

    document.querySelector("#int_list").addEventListener("click",(event)=>{
        if(event.target.id=="remove")
        { 
            selected_interests = arrayRemove(selected_interests, event.target.className);
            event.target.parentNode.parentNode.remove();
            console.log(event.target.className);
        }
    });
    function arrayRemove(arr, value){ 
        return arr.filter(function(i){ 
            return i != value; 
        });
    }
    //#endregion

    //#region Ajax Stuff
    

    $("#bt_post_img").on("click",function(e){
        var data = new FormData();
        $.each($('#file')[0].files, function(i, file) {
            data.append('file-'+i, file);
        });
    
        $.ajax({
            url: 'http://localhost:8081/img',
            data: data,
            cache: false,
            contentType: false,
            processData: false,
            method: 'POST',
            type: 'POST', 
            success: function(data){
                alert(data);
            }
        });

        images = true;
    });

    /*
    $("#bt_post_jsonpost").on("click",function(e){
        var data = new FormData();
        $.each($('#file')[0].files, function(i, file) {
            data.append('file-'+i, file);
        });
        console.log("wee");
        $.ajax({
            url: 'http://localhost:8081/json',
            data: data,
            cache: false,
            contentType: false,
            processData: false,
            method: 'POST',
            type: 'POST', // For jQuery < 1.9
            success: function(data){
                alert(data);
            }
        });

        $("#bt_post_jsonget").show();
        $("#bt_post_jsonpost").hide();

    });
    */

    $("#bt_post").on("click",function(e){

        if(images 
                && $("#firstname").val() != '' 
                && $("#middlename").val() != ''
                && $("#lastname").val() != ''
                && $("#profession").val() != ''
                && $("#introduction").val() != ''
                && color_theme != '' )
        {
        $.ajax({
            url:"http://localhost:8081/zip",
            type:"post",
            data:{
                firstname: $("#firstname").val(), 
                middlename: $("#middlename").val(),
                lastname: $("#lastname").val(),
                profession: $("#profession").val(),
                introduction: $("#introduction").val(),
                programs: JSON.stringify(programs),
                program_dates: JSON.stringify(program_dates),
                universities: JSON.stringify(universities),
                degree_types: JSON.stringify(degree_types),
                project_names: JSON.stringify(project_names),
                project_details: JSON.stringify(project_details),
                project_date: JSON.stringify(project_date),
                exp_names: JSON.stringify(exp_names),
                exp_titles: JSON.stringify(exp_titles),
                exp_details: JSON.stringify(exp_details),
                exp_date: JSON.stringify(exp_date),
                selected_skills: JSON.stringify(selected_skills),
                selected_interests: JSON.stringify(selected_interests),
                mobile_numb: $("#mobile_numb").val(),
                email: $("#email").val(),
                instagram: $("#instagram").val(), 
	            twitter: $("#twitter").val(),
                linkedin: $("#linkedin").val(),
                github: $("#github").val(),
                youtube: $("#youtube").val(),
                facebook: $("#facebook").val(),
                color_theme: color_theme},
            dataType:"text",
            success: function(txt){
                if(txt == "Error")
                {
                    alert("Didnt Save");
                }   
                else
                {
                    alert("Saved");
                    $("#downloadSection").show();
                    $("#preview").show();
                    $("#bt_post_json").show();

                }
            }
        })
        }else {
            alert("Fill in All Fields to Save");

        }

    });

    
//#endregion