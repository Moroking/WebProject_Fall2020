let webSocket = require("ws");

let ws= new webSocket.Server({port:8080});

ws.on("connection",function(thisWs){

    if(downloadable == true)
    {
        thisWs.send(`canDownload`);

    }

    if(downloadable == false)
    {
        thisWs.send(`cantDownload`);

    }

    if(passEmp == true)
    {
        thisWs.send(`passEmp`);
        passEmp = false;
    }

    if(passCorr == true)
    {
        thisWs.send(`passCorr:${Email_Cor}:0`);
    }

    if(passInc == true)
    {
        thisWs.send(`passInc`);
        passInc = false;

    }
    
    if(googleLogin == true)
    {
        if(savedData == true)
        {
            /*
            con.query(`SELECT email FROM data WHERE email ='${googleData.emails[0]["value"]}'`, function (err, result, fields) {
                if (err) throw "does not exist";
                //result = JSON.stringify(result)
                console.log(result[0].email + "WEE");
    
                if(result[0].email == googleData.emails[0]["value"])
                {
                    thisWs.send(`googleLogin:${googleData.displayName}:1`);
                }
                else {
                    thisWs.send(`googleLogin:${googleData.displayName}:0`);
                }
               
            });
            */
           thisWs.send(`googleLogin:${googleData.displayName}:1`);

        } else {
            thisWs.send(`googleLogin:${googleData.displayName}:0`);

        }
        


       

    }
    if(googleLogin == false && passCorr == false)    
    {
        thisWs.send(`revert`);

    }
    thisWs.on("message",function(msg){
        let splitMsg= msg.split(":");
        let jsonData = "";
        

        if(splitMsg[0]=="loadusers"){
            con.query(`SELECT * FROM userdata WHERE email =?`, [googleData.emails[0]["value"]], function (err, result, fields) {
                if (err) throw err;
                jsonData = result[0].jsondata;
                                jsonData = JSON.parse(jsonData);

                                thisWs.send(`writemessage:
                                ${jsonData.firstname}:
                                ${jsonData.middlename}:
                                ${jsonData.lastname}:
                                ${jsonData.profession}:
                                ${jsonData.introduction}:
                                ${jsonData.project_names}:
                                ${jsonData.project_details}:
                                ${jsonData.project_date}:
                                ${jsonData.programs}:
                                ${jsonData.program_dates}:
                                ${jsonData.universities}:
                                ${jsonData.degree_types}:
                                ${jsonData.exp_names}:
                                ${jsonData.exp_titles}:
                                ${jsonData.exp_details}:
                                ${jsonData.exp_date}:
                                ${jsonData.selected_skills}:
                                ${jsonData.selected_interests}`);
    
            });

                
              

        }
    })
})
