function Header(firstname, lastname) {
    layout1 = '<html lang="en">'+
    '<head>'+
        '<meta charset="UTF-8">'+
        '<meta name="viewport" content="width=device-width, initial-scale=1.0">'+

        '<link rel="stylesheet" href="css/styles.css">'+

        "<link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>"+

        '<title>'+ firstname + " " + lastname + '</title>'+
    '</head>'+
    '<body>';

    return layout1;
 }

 function NavBar(firstname, middlename , lastname) {
    layout1 = '<header class="l-header">' +
    '<nav class="nav bd-grid">' +
        '<div>'+
            '<a href="#" class="nav__logo">'+ firstname + " " + middlename + " " + lastname + '</a>'+
        '</div>'+

        '<div class="nav__menu" id="nav-menu">'+
            '<ul class="nav__list">'+
                '<li class="nav__item"><a href="#home" class="nav__link active">Home</a></li>'+
                '<li class="nav__item"><a href="#about" class="nav__link">About</a></li>'+
                '<li class="nav__item"><a href="#education" class="nav__link">Education</a></li>'+
                '<li class="nav__item"><a href="#experience" class="nav__link">Experience</a></li>'+
                '<li class="nav__item"><a href="#projects" class="nav__link">Projects</a></li>'+
                '<li class="nav__item"><a href="#skills" class="nav__link">Skills</a></li>'+
                '<li class="nav__item"><a href="#interests" class="nav__link">Interests</a></li>'+
                '<li class="nav__item"><a href="#contact" class="nav__link">Contact</a></li>'+
            '</ul>'+
        '</div>'+

        '<div class="nav__toggle" id="nav-toggle">'+
            '<i class="bx bx-menu"></i>'+
        '</div>'+
    '</nav>'+
'</header>';

    return layout1;
 }

 function HomeLayout1(firstname, profession,image_loca) {
    layout1 = '<section class="home bd-grid" id="home">' +
                '<div class="home__data">'+
                    "<h1 class='home__title'>Hi,<br>I'am <span class='home__title-color'>" + firstname + "</span><br>" + profession + "</h1>" +

                    '<a href="#" class="button">Contact</a></div>' +

                

                '<div class="home__img">'+
                    '<img src='+ image_loca +' alt="">' +
                '</div>'+
            '</section>';

    return layout1;
 }

 function About(image_loca, introduction) {
    layout1 = '<section class="about section " id="about">'+
    '<h2 class="section-title">About</h2>'+

    '<div class="about__container bd-grid">'+
        '<div class="about__img">'+
            '<img src='+ image_loca +' alt="">'+
        '</div>'+
        
            '<div>'+
                '<h2 class="about__subtitle">' +introduction+'</h2>'+
                '<p class="about__text"></p>'      +
            '</div>'                 +          
        '</div>'+
    '</section>';

    return layout1;
 }

 function Education(programs,program_dates,universities,degree_types) {
    let layout1 =
    '<section class="education section" id="education">' +
       '<h2 class="section-title">Education</h2>' +

    '<div class="skills__container bd-grid">';

    for (i = 0; i < programs.length; i++) {

       layout1 += '<div class="skills__data">' +
                '<div class="skills__names">' +
                    '<span class="skills__name">'+ degree_types[i] + " in " + programs[i] +'</span> <br>' +
                    
                '</div>'+ 
                '<div class="skills__names">' +
                    '<span class="skills__name">'+ universities[i] +'</span> <br>' +
                    
                '</div>'+ 
                '<span class="skills__date">'+ program_dates[i] +'</span>'+
    
              
            '</div>';
    }

    layout1 +=   '</div>' +
   '</section>';

   return layout1;
}

 function Experience(exp_title,exp_names,exp_date,exp_details){
     let layout1 =
     '<section class="experience section" id="experience">' +
        '<h2 class="section-title">Experience</h2>' +

     '<div class="skills__container bd-grid">';

     for (i = 0; i < exp_title.length; i++) {

        layout1 += '<div class="skills__data">' +
                 '<div class="skills__names">' +
                     '<span class="skills__name">'+ exp_title[i] +'</span> <br>' +
                     
                 '</div>'+ 
                 '<div class="skills__names">' +
                     '<span class="skills__name">'+ exp_names[i] +'</span> <br>' +
                     
                 '</div>'+ 
                 '<span class="skills__date">'+ exp_date[i] +'</span>'+
                 '<br>'+
                 '<p>'+ exp_details[i] +'</p>'+
             '</div>';
     }

     layout1 +=   '</div>' +
    '</section>';

    return layout1;
}

 function Projects(project_names,project_details,project_date){
    let layout1 =
    '<section class="projects section" id="projects">' +
       '<h2 class="section-title">Projects</h2>' +

    '<div class="skills__container bd-grid">';

    for (i = 0; i < project_names.length; i++) {

       layout1 += '<div class="skills__data">' +
                '<div class="skills__names">' +
                    '<span class="skills__name">'+ project_names[i] +'</span> <br>' +
                    
                '</div>'+ 
                '<span class="skills__date">'+ project_date[i] +'</span>'+
                '<br>'+
                '<p>'+ project_details[i] +'</p>'+
            '</div>';
    }

    layout1 +=   '</div>' +
   '</section>';

   return layout1;
}

function Skills(selected_skills){
    let layout1 =
    '<section class="skills section" id="skills">' +
       '<h2 class="section-title">Skills</h2>' +

    '<div class="skills__container bd-grid">';

    for (i = 0; i < selected_skills.length; i++) {

       layout1 += '<div class="skills__data">' +
                '<div class="skills__names">' +
                    '<span class="skills__name">'+ selected_skills[i] +'</span> <br>' +
                    
                '</div>'+ 
                
            '</div>';
    }

    layout1 +=   '</div>' +
   '</section>';

   return layout1;
}

function Interests(selected_interests){
    let layout1 =
    '<section class="interests section" id="interests">' +
       '<h2 class="section-title">Interests</h2>' +

    '<div class="skills__container bd-grid">';

    for (i = 0; i < selected_interests.length; i++) {

       layout1 += '<div class="skills__data">' +
                '<div class="skills__names">' +
                    '<span class="skills__name">'+ selected_interests[i] +'</span> <br>' +
                    
                '</div>'+ 
                
            '</div>';
    }

    layout1 +=   '</div>' +
   '</section>';

   return layout1;
}

function Contact(firstname, middlename, lastname, mobile_numb, email, instagram, twitter, linkedin, github, youtube, facebook){
    let layout = 
    '<section class="contact section" id="contact">' +
                '<h2 class="section-title">Contact</h2>'+

                '<div class="contact__container bd-grid">'+
                    '<form action="" class="contact__form">'+
                        '<input type="text" placeholder="Name" class="contact__input">'+
                        '<input type="mail" placeholder="Email" class="contact__input">'+
                        '<textarea name="" id="" cols="0" rows="10" class="contact__input"></textarea>'+
                        '<input type="button" value="Send" class="contact__button button">'+
                    '</form>'+
                '</div>'+
            '</section>'+
            '<footer class="footer">'+
            '<p class="footer__title">'+ firstname + " " + middlename + " " + lastname + '</p>'+
            '<div class="footer__social">';

            if(mobile_numb != '')
            {
                layout +=  '<a href="#" class="footer__icon">'+mobile_numb+'</a> <br> <br>';
            }

            if(email != '')
            {
                layout +=  '<a href="#" class="footer__icon">'+email+'</a> <br> <br>';
            }

            if(instagram != '')
            {
                layout += '<a href='+instagram+' class="footer__icon"><i class="bx bxl-instagram" ></i></a>';
            }

            if(twitter != '')
            {
                layout += '<a href='+twitter+' class="footer__icon"><i class="bx bxl-twitter" ></i></a>';
            }

            if(linkedin != '')
            {
                layout += '<a href='+linkedin+' class="footer__icon"><i class="bx bxl-linkedin" ></i></a>';
            }

            if(github != '')
            {
                layout += '<a href='+github+' class="footer__icon"><i class="bx bxl-github" ></i></a>';
            }
            
            if(youtube != '')
            {
                layout += '<a href='+youtube+' class="footer__icon"><i class="bx bxl-youtube" ></i></a>';
            }
            
            if(facebook != '')
            {
                layout += '<a href='+facebook+' class="footer__icon"><i class="bx bxl-facebook" ></i></a>';
            }

            layout += '</div>'+
            '<p>&#169; 2020 copyright all right reserved</p>'+
            '</footer>'+

            '</body>'+
            '</html>';
            
            return layout;
}
 
